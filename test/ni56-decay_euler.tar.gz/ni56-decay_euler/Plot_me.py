# Author: M. Reichert
import numpy as np
import matplotlib.pyplot as plt


# Prepare the plot
fig, ax = plt.subplots(1, 1, sharex=True)


# Plot the testrun
path_gear = "testrun/tracked_nuclei.dat"
time,fe56_xtfc,co56_xtfc,ni56_xtfc = np.loadtxt(path_gear,unpack=True)
plt.plot(time, fe56_xtfc*56, color="tab:orange", linestyle='dashed')
plt.plot(time, co56_xtfc*56, color="tab:green", linestyle='dashed')
plt.plot(time, ni56_xtfc*56, color="tab:blue", linestyle='dashed')
plt.xscale('log')
plt.show()

