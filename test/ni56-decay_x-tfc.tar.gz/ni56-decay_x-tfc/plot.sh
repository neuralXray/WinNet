#!/bin/bash

# chmod u+x plot.sh


ifort -o ni56-decay_x-tfc-test ni56-decay_x-tfc-test.f90 -qmkl -diag-disable=10448
./ni56-decay_x-tfc-test
python Plot_me.py

