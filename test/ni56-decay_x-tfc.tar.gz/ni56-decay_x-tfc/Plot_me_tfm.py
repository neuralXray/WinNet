# Author: M. Reichert
import numpy as np
import matplotlib.pyplot as plt

import sys
sys.path.insert(0, '/home/jax/Documents/TFM/latex/')
from my_plot import set_subplots_size, tex_fonts


# Prepare the plot
subplots = (2, 1)
plt.rcParams.update(tex_fonts)
fig, ax = plt.subplots(subplots[0], subplots[1], sharex=True,
                       figsize=set_subplots_size(width='tfm', fraction=1, subplots=subplots))


y_min = 1e-3
# REACLIB rates:
lambda_ni = np.exp(-0.135415e+02)
lambda_co = np.exp(-0.160997e+02)

def analyticSol(y0,t):
    y_ni0, y_co0, y_fe0 = [y0[0], y0[1], y0[2]]
    y_ni = y_ni0*np.exp(-lambda_ni*t)
    #degenerate case?
    if(lambda_ni==lambda_co):
        y_co = y_co0*np.exp(-lambda_ni*t) + lambda_ni*y_ni0*t*np.exp(-lambda_ni*t)
    else:
        y_co = y_co0*np.exp(-lambda_co*t) + (lambda_ni/(lambda_co - lambda_ni))*y_ni0*(np.exp(-lambda_ni*t) - np.exp(-lambda_co*t))
    y_fe = np.sum(y0) - y_ni - y_co
    return np.array([y_ni, y_co, y_fe])


# Plot analytic solution
y0 = np.array([1.0/56.0, 0.0, 0.0])
t_ana = []
step = 1e4
ti = step
t_f = 1e8
while ti < t_f:
    t_ana.append(ti)
    step = step * 1.02
    ti = ti + step
t_ana.append(t_f)
t_ana = np.array(t_ana)

y_ana = analyticSol(y0, t_ana)
ax[0].plot(t_ana, y_ana[0]*56, color="k",)
ax[0].plot(t_ana, y_ana[1]*56, color="k")
ax[0].plot(t_ana, y_ana[2]*56, color="k")


# Plot the testrun
path_gear = "testrun/tracked_nuclei.dat"
time,fe56_xtfc,co56_xtfc,ni56_xtfc = np.loadtxt(path_gear,unpack=True)
ax[0].plot(time, fe56_xtfc*56, color="tab:orange", linestyle='dashed')
ax[0].plot(time, co56_xtfc*56, color="tab:green", linestyle='dashed')
ax[0].plot(time, ni56_xtfc*56, color="tab:blue", linestyle='dashed')

path_gear = "testrun/sol1.txt"
time,fe56_xtfc,co56_xtfc,ni56_xtfc = np.loadtxt(path_gear,unpack=True)
path_gear = "testrun/sol2.txt"
time, fe56_pchip, co56_pchip, ni56_pchip = np.loadtxt(path_gear,unpack=True)


# Plot the errors
principal_time_grid = [time[0]]
seconday_time_grid = []
cnt = 0
error_xtfc = []
error_pchip = []
error_time = []
for i, t in enumerate(time):
    cnt = cnt + 1
    if cnt == 5:
        principal_time_grid.append(t)
        cnt = 1
    elif cnt == 3:
        seconday_time_grid.append(t)
    else:
        y_ana = analyticSol(y0, t)
        error_time.append(t)
        error_xtfc.append(abs(np.array([ni56_xtfc[i], co56_xtfc[i], fe56_xtfc[i]]) - y_ana)*56)
        error_pchip.append(abs(np.array([ni56_pchip[i], co56_pchip[i], fe56_pchip[i]]) - y_ana)*56)
error_xtfc = np.array(error_xtfc)
error_pchip = np.array(error_pchip)
print('X-TFC', "{:e}".format(np.nanmean(error_xtfc)))
print('PCHIP', "{:e}".format(np.nanmean(error_pchip)))
for i in range(subplots[0]):
    ax[i].vlines(principal_time_grid, 0, 1, color='lightgrey', linewidth=1.2)
    ax[i].vlines(seconday_time_grid, 0, 1, color='lightgrey', linewidth=.4)
    ax[i].grid(axis='y')


# Give labels and limits to the plot
plt.xlabel("Time [s]")
ax[0].set_ylabel("Mass fraction")
ax[0].set_xlim(1e4,1e8)
ax[0].set_xscale("log")
ax[1].set_yscale("log")
ax[1].set_ylabel("Absolute error")
ax[1].set_ylim([1e-9, 1e-3])

ax[1].plot(error_time, error_xtfc[:, 0], color="tab:orange")
ax[1].plot(error_time, error_pchip[:, 0], color="tab:orange", linestyle='dashed')
ax[1].plot(error_time, error_xtfc[:, 1], color="tab:green")
ax[1].plot(error_time, error_pchip[:, 1], color="tab:green", linestyle='dashed')
ax[1].plot(error_time, error_xtfc[:, 2], color="tab:blue")
ax[1].plot(error_time, error_pchip[:, 2], color="tab:blue", linestyle='dashed')


# Create legend
a1, = plt.plot(np.nan, np.nan, color="tab:blue")
a2, = plt.plot(np.nan, np.nan, color="tab:green")
a3, = plt.plot(np.nan, np.nan, color="tab:orange")
l1, = plt.plot(np.nan, np.nan, color="tab:blue")
l2, = plt.plot(np.nan, np.nan, color="tab:blue", linestyle='dashed')
l3, = plt.plot(np.nan, np.nan, color="k")
l4, = plt.plot(np.nan, np.nan, linestyle="dashed")
ax[0].legend([a1, a2, a3, l3, l4], ["$^{56}$Ni", "$^{56}$Co", "$^{56}$Fe", "Analytic", "X-TFC"])
ax[1].legend([l1, l2], ["X-TFC", "PCHIP"])


plt.savefig("ni56_test_xtfc.pdf", bbox_inches="tight")
plt.show()

