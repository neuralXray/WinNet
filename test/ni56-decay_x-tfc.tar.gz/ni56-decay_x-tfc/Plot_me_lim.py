# Author: M. Reichert
import numpy as np
import matplotlib.pyplot as plt


# REACLIB rates:
lambda_ni = np.exp(-0.135415e+02)
lambda_co = np.exp(-0.160997e+02)

def analyticSol(y0,t):
    y_ni0, y_co0, y_fe0 = [y0[0], y0[1], y0[2]]
    y_ni = y_ni0*np.exp(-lambda_ni*t)
    #degenerate case?
    if(lambda_ni==lambda_co):
        y_co = y_co0*np.exp(-lambda_ni*t) + lambda_ni*y_ni0*t*np.exp(-lambda_ni*t)
    else:
        y_co = y_co0*np.exp(-lambda_co*t) + (lambda_ni/(lambda_co - lambda_ni))*y_ni0*(np.exp(-lambda_ni*t) - np.exp(-lambda_co*t))
    y_fe = np.sum(y0) - y_ni - y_co
    return np.array([y_ni, y_co, y_fe])


# Plot analytic solution
y0 = np.array([1.0/56.0, 0.0, 0.0])
t_ana = []
step = 1e4
ti = step
t_f = 1e8
while ti < t_f:
    t_ana.append(ti)
    step = step * 1.02
    ti = ti + step
t_ana.append(t_f)
t_ana = np.array(t_ana)

y_ana = analyticSol(y0, t_ana)
plt.plot(t_ana, y_ana[0]*56, color="k",)
plt.plot(t_ana, y_ana[1]*56, color="k")
plt.plot(t_ana, y_ana[2]*56, color="k")


# Plot the testrun
path_gear = "testrun/tracked_nuclei.dat"
time,fe56_xtfc,co56_xtfc,ni56_xtfc = np.loadtxt(path_gear,unpack=True)
plt.plot(time, fe56_xtfc*56, color="tab:orange", linestyle='dashed')
plt.plot(time, co56_xtfc*56, color="tab:green", linestyle='dashed')
plt.plot(time, ni56_xtfc*56, color="tab:blue", linestyle='dashed')


# Give labels and limits to the plot
plt.xlabel("Time [s]")
plt.ylabel("Mass fraction")
plt.xlim(1e6,1e8)
plt.ylim(1e-20,1e1)
plt.xscale("log")
plt.yscale("log")


# Create legend
a1, = plt.plot(np.nan, np.nan, color="tab:blue")
a2, = plt.plot(np.nan, np.nan, color="tab:green")
a3, = plt.plot(np.nan, np.nan, color="tab:orange")
l3, = plt.plot(np.nan, np.nan, color="k")
l4, = plt.plot(np.nan, np.nan, linestyle="dashed")
plt.legend([a1, a2, a3, l3, l4], ["$^{56}$Ni", "$^{56}$Co", "$^{56}$Fe", "Analytic", "X-TFC"])


plt.grid()
plt.savefig("ni56_test_xtfc_lim.pdf", bbox_inches="tight")
plt.show()

