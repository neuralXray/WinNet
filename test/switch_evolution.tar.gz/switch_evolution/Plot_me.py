# Author: M. Reichert
import matplotlib.pyplot as plt
import numpy             as np

# Testrun
time,temp,dens,n,p,he = np.loadtxt('testrun/mainout.dat',unpack=True,usecols=[1,2,3,6,7,8])
# Reference case
time_ref,temp_ref,dens_ref,n_ref,p_ref,he_ref = np.loadtxt('mainout.dat',unpack=True,usecols=[1,2,3,6,7,8])


nse_temp_hot  = 6.
nse_temp_cold = 5.


figure_temp = plt.figure()
ax_temp     = figure_temp.gca()
# Plot the testrun
ax_temp.plot(time,temp)
# Plot the reference run
ax_temp.plot(time_ref,temp_ref,ls='--',lw=1,color='firebrick')

ax_temp.axhline(nse_temp_cold,color='g',ls='--',lw=1.5)
ax_temp.text(0.7,nse_temp_cold+0.1,'NSE cold',color='g')

ax_temp.axhline(nse_temp_hot, color='r',ls='--',lw=1.5)
ax_temp.text(0.7,nse_temp_hot+0.1,'NSE hot',color='red')
zone1 = [0.,0.2853]
zone2 = [0.2853,0.409]
zone3 = [0.409,0.474798]
zone4 = [0.474798,0.5]
zone5 = [0.5,1.]



ax_temp.fill_between(zone1,[0,0],[10,10],color='r',alpha=0.1)
ax_temp.fill_between(zone2,[0,0],[10,10],color='g',alpha=0.1)
ax_temp.fill_between(zone3,[0,0],[10,10],color='r',alpha=0.1)
ax_temp.fill_between(zone4,[0,0],[10,10],color='g',alpha=0.1)
ax_temp.fill_between(zone5,[0,0],[10,10],color='k',alpha=0.1)



ax_temp.plot(0,-1,marker='s',alpha=0.3,color='r',lw=0.,label='NSE')
ax_temp.plot(0,-1,marker='s',alpha=0.3,color='g',lw=0.,label='Network')
ax_temp.plot(0,-1,marker='s',alpha=0.3,color='k',lw=0.,label='Expansion')
ax_temp.plot(0,-1,ls='--'   ,color='firebrick',label='Reference')
ax_temp.plot(0,-1,ls='-'    ,color='blue'     ,label='Testrun')

ax_temp.legend(loc=3,numpoints=1,fancybox=True)


ax_temp.set_ylim(0,7.5)
ax_temp.set_xlim(0,1.)

ax_temp.set_ylabel('Temperature [GK]')
ax_temp.set_xlabel('Time [s]')
figure_temp.savefig('switch_evolution.pdf',bbox_inches='tight')

# Reference abundances
figure_Y = plt.figure()
ax_Y     = figure_Y.gca()

# Plot abundances of the testrun
ax_Y.plot(time,n, color='b')
ax_Y.plot(time,p, color='b')
ax_Y.plot(time,he,color='b')

# Plot abundances of the reference run
ax_Y.plot(time_ref,n_ref, color='firebrick',ls='--')
ax_Y.plot(time_ref,p_ref, color='firebrick',ls='--')
ax_Y.plot(time_ref,he_ref,color='firebrick',ls='--')

ax_Y.set_ylabel("Abundance")
ax_Y.set_xlabel("Time [s]")

# Plot zones
ax_Y.fill_between(zone1,[0,0],[10,10],color='r',alpha=0.1)
ax_Y.fill_between(zone2,[0,0],[10,10],color='g',alpha=0.1)
ax_Y.fill_between(zone3,[0,0],[10,10],color='r',alpha=0.1)
ax_Y.fill_between(zone4,[0,0],[10,10],color='g',alpha=0.1)
ax_Y.fill_between(zone5,[0,0],[10,10],color='k',alpha=0.1)

# For legend
ax_Y.plot(0,-1,marker='s',alpha=0.3,color='r',lw=0.,label='NSE')
ax_Y.plot(0,-1,marker='s',alpha=0.3,color='g',lw=0.,label='Network')
ax_Y.plot(0,-1,marker='s',alpha=0.3,color='k',lw=0.,label='Expansion')
ax_Y.plot(0,-1,ls='--'   ,color='firebrick',label='Reference')
ax_Y.plot(0,-1,ls='-'    ,color='blue'     ,label='Testrun')


ax_Y.legend(loc=1,numpoints=1,fancybox=True)

ax_Y.set_yscale('log')
ax_Y.set_ylim(1e-10,1)

figure_Y.savefig('reference_abundances.pdf',bbox_inches='tight')


plt.show()
