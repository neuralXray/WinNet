# Default skeleton for python files
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from reaclib_class import reaclib
from winvn_class import winvn

nnn = np.loadtxt("sunet",dtype=str)
print(nnn)
#
# r=reaclib("Reaclib_v2.2")
# r.read_reaclib()
# r.filter_with_sunet(nnn)
# r.save_reaclib("reaclib_reduced")


w = winvn("winvne_v2.0.dat")
w.read_winvn()
w.filter_with_sunet(nnn)
w.write_winvn("winvn")
