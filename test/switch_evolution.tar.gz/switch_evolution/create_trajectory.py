# Author: M. Reichert
import numpy             as np
import matplotlib.pyplot as plt

amount_points = 300
time = np.linspace(0,0.5,num=amount_points)

nse_temp_cold = 5.
nse_temp_hot  = 6.



def temp_function(t):
    """
      Create temperature as a function of time
    """
    last_t = t[-1]
    amplitude = 1.7
    offset    = 5.3

    temp = offset + amplitude * np.cos((3.*np.pi/(last_t**3.)) * t**3.)

    t_hot  = (np.arccos((nse_temp_hot  - offset)/amplitude) / (3.*np.pi/(last_t**3.)))**(1./3.)
    t_cold = (np.arccos((nse_temp_cold - offset)/amplitude) / (3.*np.pi/(last_t**3.)))**(1./3.)
    return temp

def dens_function(t):
    """
      Create density as a function of time
    """
    last_t = t[-1]
    amplitude = 1.e8
    offset    = 8e8

    dens = offset + amplitude * np.cos((3.*np.pi/(last_t**3.)) * t**3.)

    return dens

# Create trajectory
ye    = np.zeros(len(time))
ye[:] = 0.5
# rad   = np.zeros(len(time))
rad   = np.linspace(1e2,1.5e2,num=amount_points)
# rad[:]= 1.e3


output = np.array([time,temp_function(time),dens_function(time),rad,ye]).T



np.savetxt('trajectory.dat',output,header = 'time[s], T9[GK], density[g/cm^3], R[km], Ye\n -----------------------------------------')




plt.plot(time,temp_function(time))
plt.axhline(nse_temp_cold,color='r',ls='--')
plt.axhline(nse_temp_hot, color='g',ls='--')



plt.ylim(0,7.5)
plt.show()

plt.plot(time,dens_function(time))
plt.ylim(1e5,1e9)
plt.show()
